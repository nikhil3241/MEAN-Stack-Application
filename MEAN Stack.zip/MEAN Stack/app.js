require('./instanthello');
const talk = require('./talk');
var goodbye = require('./talk/goodbye');
var question = require('./talk/questionbook');


talk.intro();
talk.hello("nikhil");

var answer = question.ask("What is the meaning of life?");
console.log(answer);

goodbye();