module.exports = function () {
    console.log("Goodbye");
}