var n = "Everyone";
console.log("Hello " + n);