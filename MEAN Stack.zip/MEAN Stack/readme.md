# MEAN stack app

This repo contains the MEAN stack application that is built through Full Stack Training's MEAN Stack Course.