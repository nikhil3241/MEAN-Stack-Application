console.log(1);

require('./fibonacci.js');

console.log(2);